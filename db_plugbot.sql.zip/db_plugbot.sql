-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 10, 2015 at 07:32 AM
-- Server version: 5.5.43
-- PHP Version: 5.4.4-14+deb7u5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_plugbot`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tblApp`
--

CREATE TABLE IF NOT EXISTS `tblApp` (
  `app_id` int(11) NOT NULL AUTO_INCREMENT,
  `app_status` int(11) NOT NULL,
  `app_random` varchar(255) NOT NULL,
  `app_botid` varchar(255) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_desc` varchar(255) NOT NULL,
  `app_dir` varchar(255) NOT NULL,
  `app_exec` varchar(255) NOT NULL,
  `app_file` varchar(255) NOT NULL,
  `app_download` varchar(255) NOT NULL,
  `app_interactive` int(11) NOT NULL,
  UNIQUE KEY `app_id_UNIQUE` (`app_id`),
  KEY `app_botid` (`app_botid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblBot`
--

CREATE TABLE IF NOT EXISTS `tblBot` (
  `bot_id` int(11) NOT NULL AUTO_INCREMENT,
  `bot_key` varchar(255) NOT NULL,
  `bot_privatekey` varchar(255) NOT NULL,
  `bot_name` varchar(255) NOT NULL,
  `bot_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bot_id`),
  KEY `bot_key` (`bot_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblJob`
--

CREATE TABLE IF NOT EXISTS `tblJob` (
  `job_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_date` datetime NOT NULL,
  `job_botkey` varchar(255) NOT NULL,
  `job_random` varchar(255) NOT NULL,
  `job_app_random` varchar(255) NOT NULL,
  `job_name` varchar(255) NOT NULL,
  `job_status` int(11) NOT NULL,
  `job_command` varchar(255) NOT NULL,
  `job_output` longtext,
  PRIMARY KEY (`job_id`),
  KEY `job_botkey` (`job_botkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblLog`
--

CREATE TABLE IF NOT EXISTS `tblLog` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_botkey` varchar(255) DEFAULT NULL,
  `log_date` datetime NOT NULL,
  `log_type` int(11) NOT NULL,
  `log_action` longtext NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_botkey` (`log_botkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblPlugbot`
--

CREATE TABLE IF NOT EXISTS `tblPlugbot` (
  `plugbot_id` int(11) NOT NULL AUTO_INCREMENT,
  `plugbot_help` int(11) NOT NULL,
  PRIMARY KEY (`plugbot_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblPlugbot`
--

INSERT INTO `tblPlugbot` (`plugbot_id`, `plugbot_help`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblScheduler`
--

CREATE TABLE IF NOT EXISTS `tblScheduler` (
  `scheduler_id` int(11) NOT NULL AUTO_INCREMENT,
  `scheduler_type` int(11) NOT NULL,
  `scheduler_botkey` varchar(255) NOT NULL,
  `scheduler_minute` varchar(11) NOT NULL,
  `scheduler_hour` varchar(11) NOT NULL,
  `scheduler_dom` varchar(11) NOT NULL,
  `scheduler_month` varchar(11) NOT NULL,
  `scheduler_dow` varchar(11) NOT NULL,
  `scheduler_command` varchar(255) NOT NULL,
  PRIMARY KEY (`scheduler_id`),
  KEY `scheduler_botkey` (`scheduler_botkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tblUser`
--

CREATE TABLE IF NOT EXISTS `tblUser` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL DEFAULT 'USER',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblUser`
--

INSERT INTO `tblUser` (`user_id`, `user_username`, `user_password`, `user_name`) VALUES
(1, 'admin', '375152ff56465e2683fae51c3e225c8ff3f7df44', 'ADMIN');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblApp`
--
ALTER TABLE `tblApp`
  ADD CONSTRAINT `tblApp_ibfk_1` FOREIGN KEY (`app_botid`) REFERENCES `tblBot` (`bot_key`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblJob`
--
ALTER TABLE `tblJob`
  ADD CONSTRAINT `tblJob_ibfk_1` FOREIGN KEY (`job_botkey`) REFERENCES `tblBot` (`bot_key`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblScheduler`
--
ALTER TABLE `tblScheduler`
  ADD CONSTRAINT `tblScheduler_ibfk_1` FOREIGN KEY (`scheduler_botkey`) REFERENCES `tblBot` (`bot_key`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
